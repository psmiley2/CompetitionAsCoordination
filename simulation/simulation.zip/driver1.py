import globalVars as globs
import evolution as ev
import board as brd
import hyperParameters as hp

def main():
    board = brd.Board(hp.boardWidth, hp.boardHeight)
    evolution = ev.Evolution(board, "data/r1.json")

    evolution.run()


if __name__ == "__main__":
    main()
