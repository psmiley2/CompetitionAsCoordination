import os
from PIL.Image import SAVE
import cell 
import globalVars as globs
import fitness as fit
import evolution as ev
import board as brd
import hyperParameters as hp
import genome
import json
import matplotlib.pyplot as plt
import numpy as np 
import seaborn as sns
from matplotlib.colors import ListedColormap
import fitness
from scipy.stats import ttest_ind
import pandas as pd 
# construct cmap
flatui = [ "#FFFFFF", "#FFFFFF", "#000000", "#FF0000", "#00FF00"]
my_cmap = ListedColormap(sns.color_palette(flatui).as_hex())


NUMBER_OF_SIMULATIONS = 20

def main():
    board = brd.Board(hp.boardWidth, hp.boardHeight)
    genomesInfo = []

    hp.punishForHittingBorder = False

    def convertStringKeysToIntKeys(d):
        keys = list(d.keys()) 
        for k in keys:
            d[int(k)] = d[k]
            d.pop(k, None)
        return d

    xs = []
    ys = []
    xs_f = []
    ys_f = []

    ratios = []


    for s_idx in range(NUMBER_OF_SIMULATIONS):
        FP = "data/infinite_or_finite/r" + str(s_idx) + ".json"
        with open(FP, "r") as json_file:
            data = json.load(json_file)
            genomesInfo = data["genomes"]

        hp.onlyInfinite = False

        g = genome.Genome(genomesInfo[-1]["genome"], 
            convertStringKeysToIntKeys(genomesInfo[-1]["metabolicReservoirValues"]), 
            convertStringKeysToIntKeys(genomesInfo[-1]["informationalReservoirValues"]), 
            genomesInfo[-1]["fitness"],  
        )


        board.reset(g)
        while (len(board.dynamicCells)):
            board.step()

        f = fitness.Fitness(board=board)
        f.calculate()
        # print("total score = ", f.totalScore)
        xs.append(f.totalScore)

        # -------
        g = genome.Genome(genomesInfo[0]["genome"], 
            convertStringKeysToIntKeys(genomesInfo[0]["metabolicReservoirValues"]), 
            convertStringKeysToIntKeys(genomesInfo[0]["informationalReservoirValues"]), 
            genomesInfo[0]["fitness"],  
        )

        board.reset(g)
        c = 0
        while (len(board.dynamicCells)) and c < 2000:
            board.step()
            c += 1

        f = fitness.Fitness(board=board)
        f.calculate()
        # print("total score = ", f.totalScore)
        xs_f.append(f.totalScore)

        # -------------------------


        hp.onlyInfinite = True

        g = genome.Genome(genomesInfo[-1]["genome"], 
            convertStringKeysToIntKeys(genomesInfo[-1]["metabolicReservoirValues"]), 
            convertStringKeysToIntKeys(genomesInfo[-1]["informationalReservoirValues"]), 
            genomesInfo[-1]["fitness"],  
        )

        board.reset(g)
        c = 0 
        while (len(board.dynamicCells)) and c < 2000:
            board.step()
            c += 1

        f = fitness.Fitness(board=board)
        f.calculate()
        # print("total score = ", f.totalScore)
        ys.append(f.totalScore)
        
        # -------------


        g = genome.Genome(genomesInfo[0]["genome"], 
            convertStringKeysToIntKeys(genomesInfo[0]["metabolicReservoirValues"]), 
            convertStringKeysToIntKeys(genomesInfo[0]["informationalReservoirValues"]), 
            genomesInfo[0]["fitness"],  
        )

        board.reset(g)
        while (len(board.dynamicCells)):
            board.step()

        f = fitness.Fitness(board=board)
        f.calculate()
        # print("total score = ", f.totalScore)
        ys_f.append(f.totalScore)

    
    
    print(s_idx)


    compute_T_test(xs, ys)
    plot_scatter_2D(xs, ys)
    plot_relative_drop_1D(xs, ys)
    plot_2_columns_before_after_drop(xs, ys)
    plot_relative_drop_1D_first_and_last_generation(xs_f, ys_f, xs, ys)

def plot_2_columns_before_after_drop(xs, ys):
    # plt.rcParams["figure.figsize"] = [2.00, 3.50]
    x_f = ["Normal"] * NUMBER_OF_SIMULATIONS
    x_l = ["Infinite Only"] * NUMBER_OF_SIMULATIONS
    # x_f = [0] * NUMBER_OF_SIMULATIONS
    # x_l = [1] * NUMBER_OF_SIMULATIONS
    y_f = xs
    y_l = ys

    for a, b in list(zip(y_f, y_l)):
        plt.plot(["Normal", "Infinite Only"], [a, b], 'k-', lw=.1)

    x = x_f + x_l
    y = y_f + y_l
    sns.set(style='ticks', context='talk')
    df= pd.DataFrame({'x': x, 'y': y})

    sns.swarmplot('x', 'y', data=df)
    sns.despine()
        
    # plt.scatter(x_f, y_f)
    # plt.scatter(x_l, y_l)
    
    plt.axhline(np.mean(y_f), color='blue', linewidth=2)
    plt.axhline(np.mean(y_l), color='orange', linewidth=2)
    plt.title("Taking Away Finite Reservoirs from Agents Causes a Decrease in Fitness")
    plt.ylabel("Fitness")
    plt.show()

def compute_T_test(xs, ys):
    print("T test results: ", ttest_ind(xs, ys))


def plot_relative_drop_1D(xs, ys):
    print(xs, ys)
    ys = [((x - y) / x) * 100 for x, y in list(zip(xs, ys)) if x > 0]

    xs = [""] * len(ys)
    plt.scatter(xs, ys)
    plt.axhline(np.mean(ys), color='blue', linewidth=2)
    plt.title("Relative Percent Drop In Fitness After Switching To Only Infinite Reservoirs")
    plt.ylabel("Percent Drop In Fitness")
    plt.show()

def plot_relative_drop_1D_first_and_last_generation(xs_f, ys_f, xs_l, ys_l):
    ys = [((x - y) / x) * 100 for x, y in list(zip(xs_f, ys_f)) if x > 0] + [((x - y) / x) * 100 for x, y in list(zip(xs_l, ys_l)) if x > 0]

    xs = ["first generation"] * len(xs_f) + ["last generation"] * len(xs_l)
    plt.scatter(xs, ys)
    plt.axhline(np.mean(ys[len(xs_f):]), color='blue', linewidth=2)
    plt.axhline(np.mean(ys[:len(xs_f)]), color='orange', linewidth=2)
    plt.title("Relative Percent Drop In Fitness After Switching To Only Infinite Reservoirs")
    plt.ylabel("Percent Drop In Fitness")
    plt.show()

def plot_scatter_2D(xs, ys):
    plt.scatter(xs, ys)
    plt.title("Fitness Change When Forcing Agents to Use Only Infinite Reservoirs")
    plt.xlabel("Fitness When Using Finite and Infinite Reservoirs")
    plt.ylabel("Fitness After Forcing Agent to Use Only Infinite Reservoirs")
    plt.legend(labels=["5:1 Aspect Ratio"])
    plt.grid(True)
    plt.show()



if __name__ == "__main__":
    main()