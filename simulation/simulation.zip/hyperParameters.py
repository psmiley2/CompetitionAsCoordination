import globalVars as globs 


FILEPATH = "data/test.json" 
targetShapeSpecification = []
genomeMutationRate = 5 # measure in %
rerunsPerAgent = 5
reservoirMutationPercentage = 20
populationSize = 250
survivalRate = 10
maxGenerations = 5000
boardWidth = 100
boardHeight = boardWidth
startX = int(boardWidth / 2)
startY = int(boardHeight / 2)
printLookupTableOutputs = True
printBoard = False
punishForHittingBorder = True
scaleFitness = False
useMidpointsForAspectRatio = True
saveAllRunsFromFirstAndLastGenerations = True

targetAspectRatio = 5
onlyFinite = False
onlyInfinite = False
targetSize = 400
onlyUseSizeAsFitness = False
useReservoirsAsInputs = False
useConsistency = True
