import os
import numpy as np
from PIL.Image import SAVE
import cell 
import globalVars as globs
import fitness as fit
import evolution as ev
import board as brd
import hyperParameters as hp
import genome
import json
import matplotlib.pyplot as plt
import numpy as np 
import seaborn as sns
import fitness

def main():
    genomesInfo = []
    totalFitness = 150

    fitnesses = []

    max_fitness = 150 



    FPs = [
        "data/base_new/r1.json",
    ]

    for FP in FPs:
        with open(FP, "r") as json_file:
            data = json.load(json_file)
            genomesInfo = data["genomes"]
        

        xs = list(range(len(genomesInfo)))
        ys = [genomesInfo[i]["fitness"] - 80 for i in range(len(genomesInfo))]

        fig = plt.figure()
        ax = plt.axes()
        ax.set_ylim([0, 70])
        ax.plot(xs, ys)
        ax.set(xlabel='Generation Number', ylabel='Fitness', title="Fitness Over Generations (will change title for paper)")
        ax.grid(True)
        plt.show()
        plt.clf()

if __name__ == "__main__":
    main()