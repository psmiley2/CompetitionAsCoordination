import globalVars as globs
import cell
import hyperParameters as hp
# import matplotlib.pyplot as plt
# import pylab
import os


class Board:
    def __init__(self, w, h):
        self.height = h
        self.width = w
        self.grid = [[0 for i in range(self.width)] for j in range(self.height)]
        self.cells = []
        self.avoidSpots = 0
        self.targetSpots = 0 
        self.dynamicCells = set()

    def reset(self, genome):
        self.avoidSpots = 0
        self.targetSpots = 0
        self.grid = [[0 for i in range(self.width)] for j in range(self.height)]
        # for s in hp.targetShapeSpecification: TARGET SHAPE STUFF
        #     for i in range(s["E"], s["W"] + 1):
        #         for j in range(s["N"], s["S"] + 1):
        #             self.grid[j][i] = 1
        # for row in self.grid:
        #     for c in row:
        #         if c == 0:
        #             self.avoidSpots += 1
        #         elif c == 1:
        #             self.targetSpots += 1

        # probably a bad spot for this
        if os.path.exists("lookup_table_outputs_temp.txt"):
           os.remove("lookup_table_outputs_temp.txt")

        cellInfo = genome.queryGenome(0, 0, 0)
        rootCell = cell.Cell(genome, globs.STEM, cellInfo["nMR"], cellInfo["nIR"], hp.startY, hp.startX)
        self.addCell(rootCell)
    
    def addCell(self, cell):
        self.grid[cell.x][cell.y] = cell.type
        if cell.type == globs.STEM:
            self.dynamicCells.add(cell)
    
    def step(self):
        for c in self.dynamicCells.copy():
            result = c.divide(self.getNeighboors(c.x, c.y))
            if result["dynamic"] == False:
                self.dynamicCells.remove(c)
            else:
                self.addCell(result["daughter"])
            
            # if hp.printBoard:
            #     pylab.ion()
            #     line = pylab.plot(0, 1, "ro", markersize=6)
            #     data = np.array(self.grid)
            #     rows,cols = data.shape
            #     plt.imshow(data, interpolation='none', 
            #                     extent=[0.5, 0.5+cols, 0.5, 0.5+rows], 
            #                     aspect="equal")
            #     plt.show()

    
    def getNeighboors(self, x, y):
        neighbors = {
            globs.STEM: 0, 
            globs.NERVE: 0,
            globs.SKIN: 0,
            "empty": []
        }
        for i in range(-1, 2):
            for j in range(-1, 2):
                if i == 0 and j == 0:
                    continue

                try:
                    # if self.grid[x + i][y + j] == 0 or self.grid[x + i][y + j] == 1: TARGET SHAPE STUFF
                    if self.grid[x + i][y + j] == 0:
                        neighbors["empty"].append((i, j))
                    else:
                        neighbors[self.grid[x + i][y + j]] += 1
                except:
                    pass
        return neighbors