import cell 
import globalVars as globs
import fitness as fit
import evolution as ev
import board as brd
import hyperParameters as hp
import genome
import json
import matplotlib.pyplot as plt
import numpy as np 
import seaborn as sns
from matplotlib.colors import ListedColormap
import os 

NUMBER_OF_SIMULATIONS = 2

def main():
    hp.printLookupTableOutputs = True

    def convertStringKeysToIntKeys(d):
        keys = list(d.keys()) 
        for k in keys:
            d[int(k)] = d[k]
            d.pop(k, None)
        return d

    first_board = brd.Board(hp.boardWidth, hp.boardHeight)
    last_board = brd.Board(hp.boardWidth, hp.boardHeight)
    genomesInfo = []

    for s_idx in range(NUMBER_OF_SIMULATIONS):
        FP = "data/infinite_or_finite/r" + str(s_idx) + ".json"
        with open(FP, "r") as json_file:
            data = json.load(json_file)
            genomesInfo = data["genomes"]
            json_file.close() 

        with open("lookup_table_outputs_temp.json", 'w') as outfile:
            print("[", file=outfile)
            outfile.close()  

        first_g = genome.Genome(genomesInfo[0]["genome"], 
            convertStringKeysToIntKeys(genomesInfo[0]["metabolicReservoirValues"]), 
            convertStringKeysToIntKeys(genomesInfo[0]["informationalReservoirValues"]), 
            genomesInfo[0]["fitness"],  
        )

        last_g = genome.Genome(genomesInfo[-1]["genome"], 
            convertStringKeysToIntKeys(genomesInfo[-1]["metabolicReservoirValues"]), 
            convertStringKeysToIntKeys(genomesInfo[-1]["informationalReservoirValues"]), 
            genomesInfo[-1]["fitness"],  
        )
        first_g.fillReservoirs()
        last_g.fillReservoirs()
        
        first_board.reset(last_g)
        while (len(first_board.dynamicCells)):
            first_board.step()
        
        last_board.reset(last_g)
        while (len(last_board.dynamicCells)):
            last_board.step()
        
        pie_chart(last_g, s_idx)
        

    hp.printLookupTableOutputs = False


def pie_chart(g, s_idx):
    with open("lookup_table_outputs_temp.json", 'a+') as outfile:
        print("]", file=outfile)
        outfile.close()  
    
    file=open('lookup_table_outputs_temp.json','r')
    states = [line for line in file.readlines()]
    file.close()

    target=open('lookup_table_outputs_temp.json','w')
    for i in range(len(states)):
        if i < len(states) - 2 and i != 0:
            target.write(states[i] + ",")
        else:
            target.write(states[i])
    target.close()
    

    run_data = []
    with open("lookup_table_outputs_temp.json", "r") as json_file:
        run_data = json.load(json_file)
        json_file.close() 

    d = {}
    for el in run_data:
        try:
            d[str(el)] += 1
        except:
            d[str(el)] = 1
    
    FP2 = "data/r" + str(s_idx) + ".png" 
    run_data = sorted(d, key=d.get, reverse=True)
    outputs = []
    number_of_times_used = []

    for el in run_data[:6]:
        number_of_times_used.append(d[el])
        outputs.append(el)

    fig, ax = plt.subplots(figsize=(6, 3), subplot_kw=dict(aspect="equal"))

    data = number_of_times_used

    def func(pct, allvals):
        absolute = int(np.round(pct/100.*np.sum(allvals)))
        return "{:.1f}%\n({:d})".format(pct, absolute)

    
    wedges, texts, autotexts = ax.pie(data, autopct=lambda pct: func(pct, data),
                                    textprops=dict(color="w"))

    print(wedges)
    print(texts)
    print(autotexts)

    ax.legend(wedges, outputs,
            title="Outputs",
            loc="lower center",
            bbox_to_anchor=(0.5, -0.1))

    plt.setp(autotexts, size=8, weight="bold")

    ax.set_title("Top Lookup Table Outputs/Inputs for r" + str(s_idx))

    plt.show()


    # print("lookup_table_length:", len(genomesInfo[-1]["genome"].keys()), ",", file=outfile)
    # print("number_of_outputs_used:", len(run_data), ",",file=outfile)
    # print("unique_outputs_used:", len(d), ",", file=outfile)

if __name__ == "__main__":
    main()